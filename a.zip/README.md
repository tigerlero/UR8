# UR8
The hippest and hoppest.

In this project our team will be creating a simple and **_`not beautiful`_** YouTube **_`clone`_**.

It will include:
- [x] Video Rating
- [x] Video Review
- [x] Like/ Dislike Reviews
- [x] Recommended Videos
- [x] Image Uploading
- [x] Video Uploading
- [x] Video Sort
- [x] Update Video
- [x] Delete Video
- [x] Password Reset
- [x] Channel
- [x] Subscribes
- [x] Notifications
- [ ] Auto thumbnail generate


### Enjoy!!
