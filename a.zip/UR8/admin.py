# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from UR8.models import Profile, Video, Review
from django.contrib import admin

# Register your models here.
admin.site.register(Profile)
admin.site.register(Video)
admin.site.register(Review)
